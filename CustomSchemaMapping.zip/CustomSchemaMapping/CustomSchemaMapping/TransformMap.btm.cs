namespace CustomSchemaMapping {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"CustomSchemaMapping.SourceSchema", typeof(global::CustomSchemaMapping.SourceSchema))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"CustomSchemaMapping.OutputSchema", typeof(global::CustomSchemaMapping.OutputSchema))]
    public sealed class TransformMap : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp"" version=""1.0"" xmlns:ns0=""http://CustomSchemaMapping.OutputSchema"" xmlns:s0=""http://CustomSchemaMapping.SourceSchema"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:SomeData"" />
  </xsl:template>
  <xsl:template match=""/s0:SomeData"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;Test&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;&lt;DATA&gt;&quot; , &quot;&lt;ID&gt;&quot; , string(ID/text()) , &quot;&lt;/ID&gt;&quot; , &quot;&lt;NAME&gt;&quot; , string(NAME/text()) , &quot;&lt;/NAME&gt;&quot; , &quot;&lt;YEAR&gt;&quot; , string(YEAR/text()) , &quot;&lt;/YEAR&gt;&quot; , &quot;&lt;/DATA&gt;&quot;)"" />
    <ns0:OutputData>
      <OtherElement>
        <xsl:value-of select=""$var:v1"" />
      </OtherElement>
      <BrevparamXML>
        <xsl:value-of select=""$var:v2"" />
      </BrevparamXML>
    </ns0:OutputData>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0)
{
   return param0;
}


public string StringConcat(string param0, string param1, string param2, string param3, string param4, string param5, string param6, string param7, string param8, string param9, string param10)
{
   return param0 + param1 + param2 + param3 + param4 + param5 + param6 + param7 + param8 + param9 + param10;
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _xsltEngine = @"";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"CustomSchemaMapping.SourceSchema";
        
        private const global::CustomSchemaMapping.SourceSchema _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"CustomSchemaMapping.OutputSchema";
        
        private const global::CustomSchemaMapping.OutputSchema _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltEngine {
            get {
                return _xsltEngine;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"CustomSchemaMapping.SourceSchema";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"CustomSchemaMapping.OutputSchema";
                return _TrgSchemas;
            }
        }
    }
}
